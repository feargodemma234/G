WEBSITE TEST PROJECT

Files:
- index.html: Main website page
- style.css: Website design and responsive layout
- script.js: Button interaction and current year

HOW TO TEST:
1. Download and extract this ZIP file.
2. Open the extracted folder.
3. Open index.html in a web browser.
4. Click "Test the button". You should see a success message.

HOW TO DEPLOY:
- GitHub Pages: Upload the files to a repository and enable Pages in repository settings.
- Render: Create a new Static Site connected to the repository. Use the repository root as the publish directory.

No build command or server-side setup is required.
