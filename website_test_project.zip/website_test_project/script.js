document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("testButton").addEventListener("click", function () {
  document.getElementById("buttonMessage").textContent =
    "Success! JavaScript is working correctly.";
});
